"use client";
import React from "react";

function DataSourceCard({
  name,
  status,
  lastUpdate,
  enabled,
  onToggle,
  metrics = {
    dataPoints: 0,
    accuracy: 0,
    latency: 0,
    errors: 0,
  },
  health = {
    cpu: 0,
    memory: 0,
    storage: 0,
  },
  dataFreshness = {
    lastSync: "",
    updateFrequency: "",
    nextUpdate: "",
  },
  reliability = {
    score: 0,
    trend: "stable",
    historicalUptime: 0,
  },
  verification = {
    status: "unverified",
    lastVerified: "",
    verifiedBy: "",
  },
}) {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md border border-gray-200 w-[400px]">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-roboto text-lg font-medium">{name}</h3>
        <button
          onClick={onToggle}
          className={`relative inline-flex h-6 w-11 items-center rounded-full ${
            enabled ? "bg-green-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
              enabled ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <span
          className={`h-2 w-2 rounded-full ${
            status === "active"
              ? "bg-green-500"
              : status === "warning"
              ? "bg-yellow-500"
              : "bg-red-500"
          }`}
        ></span>
        <span className="font-roboto text-sm text-gray-600 capitalize">
          {status}
        </span>
        <span
          className={`ml-2 text-xs px-2 py-0.5 rounded ${
            verification.status === "verified"
              ? "bg-green-100 text-green-800"
              : verification.status === "pending"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
          }`}
        >
          {verification.status}
        </span>
      </div>

      <div className="border-t border-gray-100 pt-3 mb-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="text-sm">
            <span className="text-gray-500">Data Points:</span>
            <span className="ml-1 font-medium">{metrics.dataPoints}</span>
          </div>
          <div className="text-sm">
            <span className="text-gray-500">Accuracy:</span>
            <span className="ml-1 font-medium">{metrics.accuracy}%</span>
          </div>
          <div className="text-sm">
            <span className="text-gray-500">Latency:</span>
            <span className="ml-1 font-medium">{metrics.latency}ms</span>
          </div>
          <div className="text-sm">
            <span className="text-gray-500">Errors:</span>
            <span
              className={`ml-1 font-medium ${
                metrics.errors > 0 ? "text-red-500" : "text-gray-700"
              }`}
            >
              {metrics.errors}
            </span>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-100 pt-3">
        <div className="grid grid-cols-3 gap-2">
          <div>
            <div className="text-xs text-gray-500 mb-1">CPU</div>
            <div className="h-1 bg-gray-200 rounded-full">
              <div
                className={`h-1 rounded-full ${
                  health.cpu > 80
                    ? "bg-red-500"
                    : health.cpu > 60
                    ? "bg-yellow-500"
                    : "bg-green-500"
                }`}
                style={{ width: `${health.cpu}%` }}
              />
            </div>
          </div>
          <div>
            <div className="text-xs text-gray-500 mb-1">Memory</div>
            <div className="h-1 bg-gray-200 rounded-full">
              <div
                className={`h-1 rounded-full ${
                  health.memory > 80
                    ? "bg-red-500"
                    : health.memory > 60
                    ? "bg-yellow-500"
                    : "bg-green-500"
                }`}
                style={{ width: `${health.memory}%` }}
              />
            </div>
          </div>
          <div>
            <div className="text-xs text-gray-500 mb-1">Storage</div>
            <div className="h-1 bg-gray-200 rounded-full">
              <div
                className={`h-1 rounded-full ${
                  health.storage > 80
                    ? "bg-red-500"
                    : health.storage > 60
                    ? "bg-yellow-500"
                    : "bg-green-500"
                }`}
                style={{ width: `${health.storage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-100 pt-3 mt-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Reliability Score</span>
          <div className="flex items-center">
            <span
              className={`text-lg font-bold ${
                reliability.score >= 90
                  ? "text-green-500"
                  : reliability.score >= 70
                  ? "text-yellow-500"
                  : "text-red-500"
              }`}
            >
              {reliability.score}%
            </span>
            <i
              className={`ml-1 fas fa-${
                reliability.trend === "up"
                  ? "arrow-up text-green-500"
                  : reliability.trend === "down"
                  ? "arrow-down text-red-500"
                  : "arrows-h text-gray-500"
              }`}
            ></i>
          </div>
        </div>
        <div className="text-xs text-gray-500">
          Historical Uptime: {reliability.historicalUptime}%
        </div>
      </div>

      <div className="border-t border-gray-100 pt-3 mt-3">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <div className="text-gray-500">Last Sync</div>
            <div className="font-medium">{dataFreshness.lastSync}</div>
          </div>
          <div>
            <div className="text-gray-500">Next Update</div>
            <div className="font-medium">{dataFreshness.nextUpdate}</div>
          </div>
        </div>
      </div>

      <p className="font-roboto text-sm text-gray-500 mt-3">
        Last verified: {verification.lastVerified} by {verification.verifiedBy}
      </p>
    </div>
  );
}

function DataSourceCardStory() {
  const [isEnabled1, setIsEnabled1] = useState(true);
  const [isEnabled2, setIsEnabled2] = useState(false);
  const [isEnabled3, setIsEnabled3] = useState(true);

  return (
    <div className="p-4 flex flex-col gap-4">
      <DataSourceCard
        name="Google Analytics"
        status="active"
        lastUpdate="2 hours ago"
        enabled={isEnabled1}
        onToggle={() => setIsEnabled1(!isEnabled1)}
        metrics={{
          dataPoints: 1250,
          accuracy: 98,
          latency: 145,
          errors: 0,
        }}
        health={{
          cpu: 45,
          memory: 60,
          storage: 30,
        }}
        dataFreshness={{
          lastSync: "10 minutes ago",
          updateFrequency: "5 minutes",
          nextUpdate: "in 4 minutes",
        }}
        reliability={{
          score: 98,
          trend: "up",
          historicalUptime: 99.9,
        }}
        verification={{
          status: "verified",
          lastVerified: "1 hour ago",
          verifiedBy: "System",
        }}
      />
      <DataSourceCard
        name="Facebook Pixel"
        status="warning"
        lastUpdate="1 day ago"
        enabled={isEnabled2}
        onToggle={() => setIsEnabled2(!isEnabled2)}
        metrics={{
          dataPoints: 850,
          accuracy: 92,
          latency: 250,
          errors: 2,
        }}
        health={{
          cpu: 75,
          memory: 85,
          storage: 65,
        }}
        dataFreshness={{
          lastSync: "1 hour ago",
          updateFrequency: "30 minutes",
          nextUpdate: "in 15 minutes",
        }}
        reliability={{
          score: 85,
          trend: "down",
          historicalUptime: 95.5,
        }}
        verification={{
          status: "pending",
          lastVerified: "6 hours ago",
          verifiedBy: "Manual",
        }}
      />
      <DataSourceCard
        name="Web Analytics"
        status="inactive"
        lastUpdate="3 hours ago"
        enabled={isEnabled3}
        onToggle={() => setIsEnabled3(!isEnabled3)}
        metrics={{
          dataPoints: 520,
          accuracy: 85,
          latency: 350,
          errors: 5,
        }}
        health={{
          cpu: 90,
          memory: 95,
          storage: 88,
        }}
        dataFreshness={{
          lastSync: "3 hours ago",
          updateFrequency: "1 hour",
          nextUpdate: "paused",
        }}
        reliability={{
          score: 65,
          trend: "stable",
          historicalUptime: 88.0,
        }}
        verification={{
          status: "unverified",
          lastVerified: "1 day ago",
          verifiedBy: "System",
        }}
      />
    </div>
  );
}

export default DataSourceCard;