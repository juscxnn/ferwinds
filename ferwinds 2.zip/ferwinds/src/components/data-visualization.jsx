"use client";
import React from "react";

function DataVisualization({
  data = {
    maritime: {
      shipTraffic: [120, 150, 180, 210, 240, 270, 300],
      cargoVolume: [500, 550, 600, 650, 700, 750, 800],
      portActivity: [80, 85, 90, 88, 92, 95, 98],
      dataQuality: {
        shipTraffic: {
          confidence: 0.95,
          verified: true,
          sources: ["MarineTraffic", "VesselFinder"],
        },
        cargoVolume: {
          confidence: 0.92,
          verified: true,
          sources: ["PortAuthority", "CustomsData"],
        },
        portActivity: {
          confidence: 0.89,
          verified: true,
          sources: ["PortOperations", "AIS"],
        },
      },
    },
    economic: {
      gdpGrowth: [2.1, 2.3, 2.7, 3.0, 3.2, 3.4, 3.6],
      tradeBalance: [-20, -15, -10, -5, 0, 5, 10],
      investment: [50, 55, 60, 65, 70, 75, 80],
      dataQuality: {
        gdpGrowth: {
          confidence: 0.97,
          verified: true,
          sources: ["WorldBank", "IMF"],
        },
        tradeBalance: {
          confidence: 0.94,
          verified: true,
          sources: ["WTO", "UNCTAD"],
        },
        investment: {
          confidence: 0.91,
          verified: true,
          sources: ["Bloomberg", "Reuters"],
        },
      },
    },
    labels: ["2018", "2019", "2020", "2021", "2022", "2023", "2024"],
  },
}) {
  const [activeTab, setActiveTab] = useState("maritime");
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [predictedData, setPredictedData] = useState(null);
  const [showQualityInfo, setShowQualityInfo] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setRotation((prev) => ({
        x: prev.x + 0.5,
        y: prev.y + 0.5,
      }));
    }, 50);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const predictTrends = () => {
      const currentData =
        activeTab === "maritime" ? data.maritime : data.economic;
      const predicted = {};

      Object.keys(currentData).forEach((key) => {
        if (key !== "dataQuality") {
          const values = currentData[key];
          const lastValue = values[values.length - 1];
          const growth =
            (lastValue - values[values.length - 2]) / values[values.length - 2];
          predicted[key] = lastValue * (1 + growth);
        }
      });

      setPredictedData(predicted);
    };

    predictTrends();
  }, [activeTab, data]);

  const renderChart = (values, color, isPredicted = false) => {
    const maxValue = Math.max(...values);
    const points = values.map((value, index) => {
      const x = 50 + index * 50;
      const y = 250 - (value / maxValue) * 200;
      const z = 0;

      const rotatedX = x * Math.cos(rotation.x) - z * Math.sin(rotation.x);
      const rotatedY = y;
      const rotatedZ = x * Math.sin(rotation.x) + z * Math.cos(rotation.x);

      return `${rotatedX},${rotatedY}`;
    });

    if (isPredicted && predictedData) {
      const lastPoint = points[points.length - 1];
      const predictedValue = predictedData[Object.keys(predictedData)[0]];
      const predictedY = 250 - (predictedValue / maxValue) * 200;
      points.push(`${50 + values.length * 50},${predictedY}`);
    }

    return (
      <g transform={`rotate(${rotation.y}, 200, 150)`}>
        <path
          d={`M ${points.join(" L ")}`}
          fill="none"
          stroke={color}
          strokeWidth={isPredicted ? 1 : 2}
          strokeDasharray={isPredicted ? "5,5" : "none"}
        />
        {points.map((point, index) => {
          const [x, y] = point.split(",");
          return (
            <circle
              key={index}
              cx={x}
              cy={y}
              r="4"
              fill={color}
              className="transform transition-all duration-300 hover:r-6"
            />
          );
        })}
      </g>
    );
  };

  const renderQualityIndicator = (metric) => {
    const qualityData =
      activeTab === "maritime"
        ? data.maritime.dataQuality[metric]
        : data.economic.dataQuality[metric];

    const confidenceColor =
      qualityData.confidence >= 0.95
        ? "green"
        : qualityData.confidence >= 0.9
        ? "yellow"
        : "red";

    return (
      <div className="absolute top-2 right-2 flex items-center gap-2">
        <div
          className="relative group"
          onMouseEnter={() => setShowQualityInfo(metric)}
          onMouseLeave={() => setShowQualityInfo(null)}
        >
          <div className="flex items-center gap-1">
            {qualityData.verified && (
              <i className="fas fa-check-circle text-green-500"></i>
            )}
            <div
              className={`w-2 h-2 rounded-full bg-${confidenceColor}-500`}
            ></div>
          </div>

          {showQualityInfo === metric && (
            <div className="absolute right-0 top-full mt-2 bg-white p-3 rounded-lg shadow-lg z-10 w-48">
              <div className="text-sm">
                <div className="font-semibold mb-1">Data Quality Metrics</div>
                <div className="flex justify-between">
                  <span>Confidence:</span>
                  <span>{(qualityData.confidence * 100).toFixed(1)}%</span>
                </div>
                <div className="mt-2">
                  <div className="font-semibold mb-1">Sources:</div>
                  <div className="text-xs">
                    {qualityData.sources.join(", ")}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full p-6 bg-white rounded-lg shadow-lg">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
        <h2 className="text-2xl font-bold font-roboto text-[#2C3E50]">
          Maritime & Economic Analytics Dashboard
        </h2>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab("maritime")}
            className={`px-4 py-2 rounded-lg font-semibold ${
              activeTab === "maritime"
                ? "bg-[#3498DB] text-white"
                : "bg-gray-100 text-gray-600"
            }`}
          >
            Maritime Data
          </button>
          <button
            onClick={() => setActiveTab("economic")}
            className={`px-4 py-2 rounded-lg font-semibold ${
              activeTab === "economic"
                ? "bg-[#3498DB] text-white"
                : "bg-gray-100 text-gray-600"
            }`}
          >
            Economic Data
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeTab === "maritime" ? (
          <>
            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                Ship Traffic Trends
              </h3>
              {renderQualityIndicator("shipTraffic")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.maritime.shipTraffic, "#3498DB")}
                  {renderChart(data.maritime.shipTraffic, "#3498DB", true)}
                </svg>
              </div>
            </div>

            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                Cargo Volume
              </h3>
              {renderQualityIndicator("cargoVolume")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.maritime.cargoVolume, "#2ECC71")}
                  {renderChart(data.maritime.cargoVolume, "#2ECC71", true)}
                </svg>
              </div>
            </div>

            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                Port Activity
              </h3>
              {renderQualityIndicator("portActivity")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.maritime.portActivity, "#E74C3C")}
                  {renderChart(data.maritime.portActivity, "#E74C3C", true)}
                </svg>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                GDP Growth Rate
              </h3>
              {renderQualityIndicator("gdpGrowth")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.economic.gdpGrowth, "#9B59B6")}
                  {renderChart(data.economic.gdpGrowth, "#9B59B6", true)}
                </svg>
              </div>
            </div>

            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                Trade Balance
              </h3>
              {renderQualityIndicator("tradeBalance")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.economic.tradeBalance, "#E74C3C")}
                  {renderChart(data.economic.tradeBalance, "#E74C3C", true)}
                </svg>
              </div>
            </div>

            <div className="relative bg-gray-50 p-4 rounded-lg transform hover:scale-105 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-4 font-roboto">
                Investment Trends
              </h3>
              {renderQualityIndicator("investment")}
              <div className="h-[300px] flex items-center justify-center perspective-[1000px]">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  {renderChart(data.economic.investment, "#F1C40F")}
                  {renderChart(data.economic.investment, "#F1C40F", true)}
                </svg>
              </div>
            </div>
          </>
        )}
      </div>

      <div className="mt-6 flex justify-center">
        <div className="flex gap-2">
          {data.labels.map((label, index) => (
            <span key={index} className="text-sm text-gray-600">
              {label}
            </span>
          ))}
          <span className="text-sm text-blue-600">Predicted</span>
        </div>
      </div>
    </div>
  );
}

function DataVisualizationStory() {
  const sampleData = {
    maritime: {
      shipTraffic: [120, 150, 180, 210, 240, 270, 300],
      cargoVolume: [500, 550, 600, 650, 700, 750, 800],
      portActivity: [80, 85, 90, 88, 92, 95, 98],
      dataQuality: {
        shipTraffic: {
          confidence: 0.95,
          verified: true,
          sources: ["MarineTraffic", "VesselFinder"],
        },
        cargoVolume: {
          confidence: 0.92,
          verified: true,
          sources: ["PortAuthority", "CustomsData"],
        },
        portActivity: {
          confidence: 0.89,
          verified: true,
          sources: ["PortOperations", "AIS"],
        },
      },
    },
    economic: {
      gdpGrowth: [2.1, 2.3, 2.7, 3.0, 3.2, 3.4, 3.6],
      tradeBalance: [-20, -15, -10, -5, 0, 5, 10],
      investment: [50, 55, 60, 65, 70, 75, 80],
      dataQuality: {
        gdpGrowth: {
          confidence: 0.97,
          verified: true,
          sources: ["WorldBank", "IMF"],
        },
        tradeBalance: {
          confidence: 0.94,
          verified: true,
          sources: ["WTO", "UNCTAD"],
        },
        investment: {
          confidence: 0.91,
          verified: true,
          sources: ["Bloomberg", "Reuters"],
        },
      },
    },
    labels: ["2018", "2019", "2020", "2021", "2022", "2023", "2024"],
  };

  return (
    <div className="p-4 bg-gray-100">
      <DataVisualization data={sampleData} />
    </div>
  );
}

export default DataVisualization;