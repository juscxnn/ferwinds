"use client";
import React from "react";

function FeedbackForm({
  onSubmit,
  initialRating = 0,
  initialComment = "",
  dataSourceId = null,
}) {
  const [rating, setRating] = useState(initialRating);
  const [comment, setComment] = useState(initialComment);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [aiResponse, setAiResponse] = useState("");
  const [impactScore, setImpactScore] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [feedbackHistory, setFeedbackHistory] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsAnalyzing(true);

    try {
      const response = await fetch("/api/collect-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rating,
          comment,
          dataSourceId,
          type: "feedback_analysis",
          timestamp: new Date().toISOString(),
        }),
      });

      const data = await response.json();
      setAiResponse(data.aiResponse);
      setImpactScore(data.impactScore);

      const newFeedback = {
        rating,
        comment,
        aiResponse: data.aiResponse,
        impactScore: data.impactScore,
        timestamp: new Date().toISOString(),
      };

      setFeedbackHistory((prev) => [...prev, newFeedback]);
      onSubmit(newFeedback);
    } catch (error) {
      setAiResponse("Failed to analyze feedback");
    }

    setIsAnalyzing(false);
    setRating(0);
    setComment("");
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold font-roboto mb-2">
            Data Quality Feedback
          </h2>
          <div className="flex justify-center space-x-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredStar(star)}
                onMouseLeave={() => setHoveredStar(0)}
                className="text-2xl focus:outline-none"
              >
                <i
                  className={`fas fa-star ${
                    star <= (hoveredStar || rating)
                      ? "text-yellow-400"
                      : "text-gray-300"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        <div>
          <textarea
            name="feedback"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Share your thoughts about the data quality..."
            className="w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={4}
          />
        </div>

        {aiResponse && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-roboto font-medium mb-2">AI Analysis</h3>
            <p className="text-sm text-gray-600">{aiResponse}</p>
            {impactScore && (
              <div className="mt-2">
                <div className="text-sm text-gray-600 mb-1">Impact Score</div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div
                    className="h-2 bg-blue-500 rounded-full transition-all duration-500"
                    style={{ width: `${impactScore}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {feedbackHistory.length > 0 && (
          <div className="mt-4">
            <h3 className="font-roboto font-medium mb-2">
              Recent Feedback History
            </h3>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {feedbackHistory.map((feedback, index) => (
                <div key={index} className="text-sm bg-gray-50 p-2 rounded">
                  <div className="flex justify-between">
                    <div className="flex items-center">
                      {[...Array(feedback.rating)].map((_, i) => (
                        <i
                          key={i}
                          className="fas fa-star text-yellow-400 text-xs"
                        />
                      ))}
                    </div>
                    <span className="text-gray-500">
                      {new Date(feedback.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-600 mt-1">{feedback.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors duration-200 flex items-center justify-center"
          disabled={!rating || isAnalyzing}
        >
          {isAnalyzing ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2" />
              Analyzing...
            </>
          ) : (
            "Submit Feedback"
          )}
        </button>
      </form>
    </div>
  );
}

function FeedbackFormStory() {
  const mockDataSourceId = "ds123";
  const mockSubmit = async (feedback) => {
    return {
      aiResponse: `Analysis: ${
        feedback.comment.length > 50
          ? "Detailed feedback provided"
          : "Brief feedback provided"
      }. 
                   Impact on data quality metrics will be evaluated.`,
      impactScore: Math.floor(Math.random() * 100),
    };
  };

  return (
    <div className="p-4 space-y-8">
      <div>
        <h3 className="font-roboto text-lg mb-2">Default Feedback Form</h3>
        <FeedbackForm onSubmit={mockSubmit} dataSourceId={mockDataSourceId} />
      </div>

      <div>
        <h3 className="font-roboto text-lg mb-2">Pre-filled Feedback Form</h3>
        <FeedbackForm
          initialRating={4}
          initialComment="Great data quality and consistency!"
          onSubmit={mockSubmit}
          dataSourceId={mockDataSourceId}
        />
      </div>

      <div>
        <h3 className="font-roboto text-lg mb-2">Form with AI Response</h3>
        <FeedbackForm
          initialRating={3}
          initialComment="Some inconsistencies in the maritime data timestamps"
          onSubmit={mockSubmit}
          dataSourceId={mockDataSourceId}
        />
      </div>
    </div>
  );
}

export default FeedbackForm;