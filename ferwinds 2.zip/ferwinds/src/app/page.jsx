"use client";
import React from "react";
import DataVisualization from "../components/data-visualization";

function MainComponent() {
  const [selectedType, setSelectedType] = useState("all");
  const [showAlerts, setShowAlerts] = useState(false);
  const [visualizationData, setVisualizationData] = useState({
    maritime: {
      shipTraffic: [150, 180, 220, 280, 320, 380, 420],
      cargoVolume: [550, 600, 680, 720, 800, 850, 920],
      portActivity: [85, 88, 92, 94, 96, 97, 98],
      aisData: [980, 1050, 1150, 1200, 1220, 1240, 1250],
      dataQuality: {
        shipTraffic: {
          confidence: 0.95,
          verified: true,
          sources: ["AISHub", "MarineTraffic", "VesselFinder"],
        },
        cargoVolume: {
          confidence: 0.92,
          verified: true,
          sources: ["PortAuthority", "CustomsData"],
        },
        portActivity: {
          confidence: 0.89,
          verified: true,
          sources: ["PortOperations", "AIS"],
        },
        aisSignals: {
          confidence: 0.97,
          verified: true,
          sources: ["AISHub"],
        },
      },
    },
    labels: ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Day 7"],
  });

  const fetchData = useCallback(async () => {
    try {
      const response = await fetch("/api/collect-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sources: [
            "aishub",
            "maritime_agents",
            "vessel_metrics",
            "anomaly_detection",
          ],
          fields: [
            "status",
            "vessel_data",
            "cargo_data",
            "route_data",
            "alerts",
            "reliability_metrics",
            "validation_scores",
            "ais_signals",
            "vessel_positions",
            "collision_risks",
          ],
        }),
      });

      const data = await response.json();
      if (data.results) {
        setAgents((prevAgents) =>
          prevAgents.map((agent) => ({
            ...agent,
            ...data.results.find((result) => result.id === agent.id),
          }))
        );

        setMetrics((prevMetrics) => ({
          ...prevMetrics,
          ...data.results.reduce(
            (acc, curr) => ({
              ...acc,
              [curr.type]: curr.value,
            }),
            {}
          ),
        }));
      }
    } catch (error) {
      console.error("Error fetching maritime data:", error);
    }
  }, []);

  const [agents, setAgents] = useState([
    {
      id: 1,
      name: "AISHub Monitor",
      status: "active",
      dataPoints: 1250,
      accuracy: 98,
      lastActive: "2024-01-20 14:30",
      type: "vessel tracking",
      activity: [
        "Detected vessel arrival",
        "Updated port capacity",
        "Processed berthing request",
        "AIS signal received",
        "Position updated",
      ],
      reliability: 97,
      validationScore: 95,
      dataQuality: 96,
      verificationStatus: "verified",
      vesselCount: 245,
      alerts: ["Collision risk detected", "Speed violation"],
      taskQueue: [
        "Update vessel positions",
        "Process AIS signals",
        "Validate data integrity",
        "Generate alerts",
        "Update statistics",
      ],
      currentOperation: "Processing AIS data stream",
    },
    {
      id: 2,
      name: "Cargo Scanner",
      status: "idle",
      dataPoints: 850,
      accuracy: 95,
      lastActive: "2024-01-20 12:15",
      type: "cargo monitoring",
      activity: [
        "Scanned container manifest",
        "Verified cargo weight",
        "Flagged suspicious cargo",
      ],
      reliability: 92,
      validationScore: 88,
      dataQuality: 90,
      verificationStatus: "trusted",
      containerCount: 156,
      alerts: [],
      taskQueue: [
        "Scan new manifests",
        "Update cargo database",
        "Run security checks",
        "Generate reports",
      ],
      currentOperation: "Scanning manifests",
    },
    {
      id: 3,
      name: "Route Tracker",
      status: "active",
      dataPoints: 2100,
      accuracy: 97,
      lastActive: "2024-01-20 14:45",
      type: "navigation data",
      activity: [
        "Updated weather conditions",
        "Optimized route",
        "Detected route deviation",
        "AIS track recorded",
        "ETA calculated",
      ],
      reliability: 94,
      validationScore: 92,
      dataQuality: 93,
      verificationStatus: "verified",
      activeRoutes: 89,
      alerts: ["Weather advisory"],
      taskQueue: [
        "Track vessel routes",
        "Calculate ETAs",
        "Monitor weather",
        "Check deviations",
        "Update route database",
      ],
      currentOperation: "Tracking active vessels",
    },
  ]);
  const [metrics, setMetrics] = useState({
    vesselsTracked: 420,
    cargoProcessed: 850,
    activeShipRoutes: 125,
    alerts: 3,
    anomalies: 2,
    averageReliability: 94.3,
    dataQualityScore: 93.8,
    aisSignals: 1250,
    vesselPositions: 420,
    collisionRisks: 2,
    activeAgents: 2,
    totalTasks: 14,
    completedTasks: 156,
    failedTasks: 3,
    agentUptime: 99.8,
    processingSpeed: 850,
    dataAccuracy: 97.2,
    systemLoad: 65,
  });

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const filteredAgents = useMemo(() => {
    if (selectedType === "all") return agents;
    return agents.filter((agent) => agent.type === selectedType);
  }, [agents, selectedType]);
  const getReliabilityBadge = (score) => {
    if (score >= 95)
      return {
        icon: "fa-check-circle",
        color: "text-green-500",
        label: "Verified",
      };
    if (score >= 85)
      return {
        icon: "fa-shield-check",
        color: "text-blue-500",
        label: "Trusted",
      };
    return {
      icon: "fa-exclamation-circle",
      color: "text-yellow-500",
      label: "Unverified",
    };
  };
  const getValidationStatus = (lastUpdate) => {
    const timeDiff = new Date() - new Date(lastUpdate);
    const minutes = Math.floor(timeDiff / 60000);
    return minutes < 5 ? "real-time" : minutes < 30 ? "recent" : "stale";
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold font-roboto">
              Agent Control Panel
            </h2>
            <div className="flex gap-2">
              <button className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                <i className="fas fa-play mr-2"></i>Start All
              </button>
              <button className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
                <i className="fas fa-stop mr-2"></i>Stop All
              </button>
              <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                <i className="fas fa-sync mr-2"></i>Sync
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {filteredAgents.map((agent) => (
              <div key={agent.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        agent.status === "active"
                          ? "bg-green-500"
                          : "bg-gray-400"
                      } mr-2`}
                    ></div>
                    <span className="font-medium">{agent.name}</span>
                  </div>
                  <div className="flex gap-2">
                    <button className="text-gray-600 hover:text-blue-600">
                      <i className="fas fa-cog"></i>
                    </button>
                    <button className="text-gray-600 hover:text-red-600">
                      <i className="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="text-gray-500">Tasks in Queue:</span>
                    <span className="ml-2 font-medium">5</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-500">Current Operation:</span>
                    <span className="ml-2 font-medium">
                      {agent.activity[0]}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold font-roboto text-gray-800">
            Maritime Operations Dashboard
          </h1>
          <div className="flex space-x-4">
            <button
              onClick={() => setShowAlerts(!showAlerts)}
              className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors relative"
            >
              <i className="fas fa-bell mr-2"></i>
              Alerts
              {metrics.alerts > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-700 text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {metrics.alerts}
                </span>
              )}
            </button>
            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
              <i className="fas fa-broadcast-tower mr-2"></i>
              AIS Status
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500 mb-2">Vessels Tracked</div>
            <div className="text-2xl font-bold text-blue-600">
              {metrics.vesselsTracked}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500 mb-2">AIS Signals</div>
            <div className="text-2xl font-bold text-green-600">
              {metrics.aisSignals}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500 mb-2">Collision Risks</div>
            <div className="text-2xl font-bold text-red-600">
              {metrics.collisionRisks}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500 mb-2">Data Quality Score</div>
            <div className="text-2xl font-bold text-purple-600">
              {metrics.dataQualityScore}%
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <DataVisualization data={visualizationData} />
          </div>
          <div className="space-y-4">
            {filteredAgents.map((agent) => (
              <DataSourceCard
                key={agent.id}
                name={agent.name}
                status={agent.status}
                lastUpdate={agent.lastActive}
                enabled={agent.status === "active"}
                onToggle={() => {}}
                metrics={{
                  dataPoints: agent.dataPoints,
                  accuracy: agent.accuracy,
                  latency: 0,
                  errors: 0,
                }}
                health={{
                  cpu: agent.reliability,
                  memory: agent.validationScore,
                  storage: agent.dataQuality,
                }}
                verification={{
                  status: agent.verificationStatus,
                  lastVerified: agent.lastActive,
                  verifiedBy: "AISHub",
                }}
              />
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <div className="flex flex-wrap gap-2">
              {[
                "all",
                "vessel tracking",
                "cargo monitoring",
                "navigation data",
              ].map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedType(type)}
                  className={`px-3 py-1 rounded-full text-sm ${
                    selectedType === type
                      ? "bg-blue-500 text-white"
                      : "bg-gray-100 text-gray-600"
                  }`}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Agent
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Reliability
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Validation
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quality
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredAgents.map((agent) => {
                const badge = getReliabilityBadge(agent.reliability);
                const validationStatus = getValidationStatus(agent.lastActive);
                return (
                  <tr key={agent.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                          <i className="fas fa-anchor text-gray-500"></i>
                        </div>
                        <div className="ml-4 font-medium text-gray-900">
                          {agent.name}
                          <i
                            className={`fas ${badge.icon} ${badge.color} ml-2`}
                            title={badge.label}
                          ></i>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {agent.type}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          agent.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {agent.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className={`h-2 rounded-full ${
                              agent.reliability >= 95
                                ? "bg-green-500"
                                : agent.reliability >= 85
                                ? "bg-blue-500"
                                : "bg-yellow-500"
                            }`}
                            style={{ width: `${agent.reliability}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">
                          {agent.reliability}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          validationStatus === "real-time"
                            ? "bg-green-100 text-green-800"
                            : validationStatus === "recent"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {validationStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span
                          className={`text-sm font-medium ${
                            agent.dataQuality >= 95
                              ? "text-green-600"
                              : agent.dataQuality >= 85
                              ? "text-blue-600"
                              : "text-yellow-600"
                          }`}
                        >
                          {agent.dataQuality}%
                        </span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;